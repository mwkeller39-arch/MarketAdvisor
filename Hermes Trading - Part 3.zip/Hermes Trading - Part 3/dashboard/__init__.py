"""Local tracking dashboard (FastAPI)."""
